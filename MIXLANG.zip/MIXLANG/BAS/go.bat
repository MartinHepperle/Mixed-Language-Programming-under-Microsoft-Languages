:REM name of BASIC module
SET BMAIN=ASM
:REM name of ASSEMBLER module
SET ASUBS=FUNC
:REM
:REM --- compile BASIC code module with Quick Basic 4.5
BC.EXE %BMAIN%,%BMAIN%,%BMAIN%
IF ERRORLEVEL 4 GOTO ERR 
:REM
:REM --- assemble ASSEMBLER code module
..\MASM ..\%ASUBS%,%ASUBS%,%ASUBS%,%ASUBS%
:REM
:REM --- link BASIC main and assembler code modules
..\LINK /M %BMAIN%+%ASUBS%,%BMAIN%,%BMAIN%;
:REM
:ERR

