/* -------------------------------------- */
/*                                        */
/* "C" Testbed Program                    */
/*                                        */
/* Microsoft Quick C 2.5                  */
/* Martin Hepperle, 2024                  */
/*                                        */
/* -------------------------------------- */

#include <stdio.h>

typedef long INTEGER4;

/* _fortran  suppressed leading _ character in names */

/* Assembler and C functions        */
extern INTEGER4 _far _fortran AFUNC ( INTEGER4 _far * I );

/* *** bit manipulation subroutines      */
extern INTEGER4 _far _fortran BINAND ( INTEGER4 _far * I1, INTEGER4 _far * I2 );
extern INTEGER4 _far _fortran BINIOR ( INTEGER4 _far * I1, INTEGER4 _far * I2 );
extern INTEGER4 _far _fortran BINXOR ( INTEGER4 _far * I1, INTEGER4 _far * I2 );

extern void _far _fortran GETTIM ( INTEGER4 _far * H, INTEGER4 _far * M, INTEGER4 _far * S, INTEGER4 _far * C );
extern void _far _fortran GETDAT ( INTEGER4 _far * D, INTEGER4 _far * M, INTEGER4 _far * Y );

extern INTEGER4 _far _fortran GETPAR ( char _far * BUFFER );

extern void _far _fortran NUMBIN ( INTEGER4 _far * N, char _far * BUFFER );
extern void _far _fortran NUMHEX ( INTEGER4 _far * N, char _far * BUFFER );

INTEGER4 _far CFUNC ( INTEGER4 _far * pI )
{
   return *pI + 100;
}

/* -------------------------------------- */

void main()
{
      

/* variables                             */
   char BUFFER[80];
   INTEGER4 I, J, IRET;
   INTEGER4 I2;
   INTEGER4 DAY,MONTH,YEAR;
   INTEGER4 HOURS,MINS,SECS,CENTIS;

   /* ***************************************** */
   /* *** Test 1: date and time                 */
   GETTIM(&HOURS,&MINS,&SECS,&CENTIS);
   printf("Now  :%02ld:%02ld:%02ld.%02ld\n",HOURS,MINS,SECS,CENTIS);

   GETDAT(&DAY,&MONTH,&YEAR);
   printf("Today: %02ld.%02ld.%04ld\n",DAY,MONTH,YEAR);

   /* ***************************************** */
   /* *** Test 2: bit manipulation functions    */
   /*     I AND J = 1536                        */
   I = 3584;
   J = 1536;
   IRET = BINAND(&I,&J);
   printf("%ld AND %ld = %ld\n",I,J,IRET);

   /*     I OR J = 3                            */
   I = 1;
   J = 2;
   IRET = BINIOR(&I,&J);
   printf("%ld IOR %ld = %ld\n",I,J,IRET);

   /*     I XOR J = 2                           */
   I = 1;
   J = 3;
   IRET = BINXOR(&I,&J);
   printf("%ld XOR %ld = %ld\n",I,J,IRET);

   /*     I XOR J = 2                           */
   I = 1;
   J = -1;
   IRET = BINXOR(&I,&J);
   printf("%ld XOR %ld = %ld\n",I,J,IRET);

   /* ***************************************** */
   /* *** Test 3: assembler versus Pascal function */
   I = 1011;
      
   /*     AFUNC and PFUNC add 100 to its parameter I */

   /*     *** call assembler routine */
   IRET = AFUNC(&I);
   printf("Assembler: 1011 + 100 = %ld\n",IRET);
      
   /*     *** call Pascal routine */
   IRET = CFUNC(&I);
   printf("C:         1011 + 100 = %ld\n",IRET);
      
   /* ***************************************** */
   /* *** Test 4: getting the tail of the command line */
   IRET = GETPAR ( BUFFER );
   /* convert Integer4 to Integer to allow array index */
   BUFFER[IRET] = '>';
   BUFFER[IRET+1] = '\0';  /* terminator */
      
   printf("Command Tail: Length = %ld <%s\n",IRET,BUFFER);
   
   /* ***************************************** */
   /* *** Test 5: 32-bit integer conversion */
   I = -2;
   NUMBIN ( &I, BUFFER );
   BUFFER[32] = '\0';  /* terminator */
   printf("Binary of      %ld = %sb\n",I,BUFFER);
   
   NUMHEX ( &I, BUFFER );
   BUFFER[8] = '\0';  /* terminator */
   printf("Hexadecimal of %ld = %sh\n",I,BUFFER);
   /*     -------------------------------------- */
}
