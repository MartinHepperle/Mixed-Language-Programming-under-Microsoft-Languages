;
; Microsoft Cobol 5.0;
; There is ONLY ONE difference to FORTRAN, Pascal, C, BASIC:
; all binary integers are 16 bit, not 32 bit.
;
; In COBOL 5, the remaining call parameters can be made identical
; to FORTRAN, Pascal, C, BASIC:
; COMP-5            integers are in Intel little-endian format [low,high]
; CALL-CONVENTION 9 parameters are pushed in left-to-right order
; BY REFERENCE      parameters are transferred as FAR pointers
;
; Notes:
; Using COMP-0 as in old COBOLs would require byte swapping
; COMP-0            integers are in Motorola big-endian format [high,low]
; Older COBOLs may use near pointers to address parameters

; Cobol 5.0 calls a function (with return value) like this:
;
;     CALL PAS-CALLCONV 'BINXOR' USING BY REFERENCE BNUM1
;                                      BY REFERENCE BNUM2
;                                      RETURNING BNUM3.
;
; Notes: The BY REFERENCE attribute makes no difference, in COBOL 5 
;        the parameters are always transferred as far pointers.
;        The PAS-CALLCONV calling convention as defined by
;        CALL-CONVENTION 9 IS PAS-CALLCONV
;        in the SPECIAL-NAMES section of the ENVIRONMENT division
;        produces the left-to-right order of the parameters,
;        as desired for compatibility with other languages.
;        And it leaves the cleanup of the stack as a task for
;        the subroutine.
;
; COBOL .GRP file:
;     MOV     [BP+5Eh],SP    ; save SP, DS and ES have been saved already
;
;     PUSH    DS             ; push segment of the first parameter 
;     MOV     AX,01C8h       ; ... offset of BNUM1
;     PUSH    AX             ; ...
;
;     PUSH    DS             ; push segment of second parameter
;     MOV     AX,01D0h       ; ... offset of BNUM2
;     PUSH    AX             ; ...
;
;     MOV     CX,0002h       ; parameter count from USING clause
;                            ; could/should be tested in subroutines
;     CALL    BINXOR
;
;     MOV     SP,[BP+5Eh]    ; restore SP (has been saved before CALL)
;     MOV     DS,[BP+68h]    ; restore DS (has been saved globally)
;     MOV     ES,[BP+68h]    ; restore ES (has been saved globally)
;     MOV     DS:[01D8h],AX  ; return value for functions
;


; simple macro to make accessing far parameters more clear
; OFF_P is the offset from BP frame to the far ptr
LOAD_ESDI MACRO OFF_P
             LES  DI,DWORD PTR [BP]. OFF_P
          ENDM


DATA SEGMENT PUBLIC 'DATA'
; we have no data
DATA ENDS


DGROUP GROUP DATA

CODE SEGMENT PUBLIC 'CODE'
     ;
     ASSUME CS:CODE, DS:DGROUP, SS:DGROUP
     
; =================================================================

;
; Return the current time 
; Usage:
;       SUBROUTINE GETTIM ( INTEGER*2 HOURS,MINUTES,SECONDS,HUNDREDS )
;
; Microsoft Cobol 5.0
; Created by Martin Hepperle, 2024
;
GETTIM_FRAME STRUC
               DW ?         ;  0  saved BP
               DW 2 DUP(?)  ;  2  RETURN address
   P_CENTIES   DW 2 DUP(?)  ;  6 last parameter
   P_SECONDS   DW 2 DUP(?)  ;  A next to last
   P_MINUTES   DW 2 DUP(?)  ;  E ...
   P_HOURS     DW 2 DUP(?)  ; 12 first parameter
GETTIM_FRAME ENDS

PUBLIC GETTIM

GETTIM PROC FAR
     PUSH BP             ; save BP
     
     ; Stack frame is now:
     ; +12   OFF/SEG - 1/100 parameter address
     ; +E    OFF/SEG - SECS parameter address
     ; +A    OFF/SEG - MINS parameter address
     ; +6    OFF/SEG - HRS parameter address
     ; +4    SEG - return address
     ; +2    OFF /
     ; SP -> BP - saved
     
     ; we could test CX for 4 to make sure that 4 parameters were given
     ; if not, we could return

     MOV  BP,SP          ; use BP for addressing of parameters

     
     MOV  AH,2CH         ; MS-DOS function 2CH
     INT  21H            ; returns CH=hours 0-23, CL=mins 0-59, DH=secs 0-59, DL=1/100 secs 0-99
     
     ; get the fourth argument
     LOAD_ESDI P_CENTIES             ; ES:[DI] addresses 1/100 secs parameter
     MOV  BYTE PTR ES:[DI+0],DL      ; 1/100 seconds to byte 0
     MOV  BYTE PTR ES:[DI+1],0       ; zero byte 1
     ; do nothing with high word - Cobol only uses 16-bit integers
          
     ; get the third argument
     LOAD_ESDI P_SECONDS             ; ES:[DI] addresses the seconds
     MOV  BYTE PTR ES:[DI+0],DH      ; seconds to byte 0
     MOV  BYTE PTR ES:[DI+1],0       ; zero byte 1
     
     ; get the second argument
     LOAD_ESDI P_MINUTES             ; ES:[DI] addresses the minutes
     MOV  BYTE PTR ES:[DI+0],CL      ; minutes to byte 0
     MOV  BYTE PTR ES:[DI+1],0       ; zero byte 1
     
     ; get the first argument
     LOAD_ESDI P_HOURS               ; ES:[DI] addresses the hours
     MOV  BYTE PTR ES:[DI+0],CH      ; hour to byte 0
     MOV  BYTE PTR ES:[DI+1],0       ; zero byte 1
     
     POP  BP              ; restore BP
     
     RET  4*4              ; drop the 4 far parameter addresses

GETTIM ENDP

; =================================================================

;
; Return the current date. 
; Usage:
;       SUBROUTINE GETDAT ( INTEGER*2 DAY, MONTH, YEAR )
;
; Microsoft Cobol 5.0
; Created by Martin Hepperle, 2024
;

GETDAT_FRAME STRUC
   BPSAVE    DW ?        ;  0
   RETURN    DW 2 DUP(?) ;  2
   P_YEAR    DW 2 DUP(?) ;  6  last parameter
   P_MONTH   DW 2 DUP(?) ;  A  next to last
   P_DAY     DW 2 DUP(?) ;  E  ...
GETDAT_FRAME ENDS

PUBLIC GETDAT
GETDAT PROC FAR
     PUSH BP             ; save BP
     
     ; Stack frame is now:
     ; +E    OFF - day parameter address
     ; +A    OFF - month parameter address
     ; +6    OFF - year parameter address
     ; +4    SEG - return address
     ; +2    OFF /
     ; SP -> BP - saved
     
     MOV  BP,SP          ; use BP for addressing of parameters

     
     MOV  AH,2AH         ; MS-DOS function 2AH
     INT  21H            ; returns CX=year 1980-2099, DH=month 1-12, DL=day 1-31
     
     ; get address of third argument (year)
     LOAD_ESDI P_YEAR
     ;LES  DI,[BP+6]               ; ES:[DI] addresses year parameter
     MOV  WORD PTR ES:[DI],CX      ; year lower 16-bit word
     
     ; get address of second argument (month)
     LOAD_ESDI P_MONTH
     ;LES  DI,[BP+0AH]             ; ES:[DI] addresses the month parameter
     MOV  BYTE PTR ES:[DI+0],DH    ; month to lower byte
     MOV  BYTE PTR ES:[DI+1],0     ; zero upper byte
     
     ; get address of first argument (day)
     LOAD_ESDI P_DAY
     ;LES  DI,[BP+0EH]             ; ES:[DI] addresses the day
     MOV  BYTE PTR ES:[DI],DL      ; day to lower byte
     MOV  BYTE PTR ES:[DI+1],0     ; zero upper byte
     
     POP  BP             ; restore BP
     
     RET  3*4             ; drop the 3 far parameter addresses

GETDAT ENDP

; =================================================================

;
; Binary AND, IOR and XOR functions. 
;
; Usage:
;       IRET = BINAND(I1,I2) binary I1 AND I2 
;       IRET = BINIOR(I1,I2) binary INCLUSIVE I1 IOR I2
;       IRET = BINXOR(I1,I2) binary EXCLUSIVE I1 XOR I2
;
; Microsoft Cobol 5.0
; Created by Martin Hepperle, 2024
;

BINOPS_FRAME STRUC
           DW ?          ;  0  saved BP 
           DW 2 DUP(?)   ;  2  far return address
   BITS_2  DW 2 DUP(?)   ;  6  far address of last parameter
   BITS_1  DW 2 DUP(?)   ;  A  far address of first parameter
BINOPS_FRAME ENDS


PUBLIC BINIOR
BINIOR PROC FAR
     
     MOV AL,0Bh              ; OR
     JMP BINOP

BINIOR ENDP

PUBLIC BINXOR
BINXOR PROC FAR
     
     MOV AL,33h              ; XOR
     JMP BINOP

BINXOR ENDP

PUBLIC BINAND
BINAND PROC FAR

     
     MOV AL,23h                    ; AND
     ; JMP BINOP

BINOP:
     ; common self modifying code for BIN operations
     ;  23 C1         AND  AX,CX         ; BITS_1 AND BITS_2
     ;  0B C1         OR   AX,CX         ; BITS_1 IOR BITS_2
     ;  33 C1         XOR  AX,CX         ; BITS_1 XOR BITS_2
     
     MOV BYTE PTR CS:OP,AL         ; patch instruction code
     
     PUSH BP                       ; save BP

     ; Stack frame is now:
     ; +A    OFF/SEG - BITS_1 address
     ; +6    OFF/SEG - BITS_2 address
     ; +2    OFF/SEG - return address
     ; SP -> BP - saved

     MOV  BP,SP                    ; use BP for addressing of parameters
     PUSH DI
     PUSH ES
     
     ; get address of first argument
     LOAD_ESDI BITS_1
     MOV  AX,WORD PTR ES:[DI]      ; 
     
     ; get address of second argument
     LOAD_ESDI BITS_2
     MOV  CX,WORD PTR ES:[DI]      ; 
     
OP:                                ; patch here for operator
     AND  AX,CX                    ; BITS_1 AND BITS_2
     
     ; return result in AX

     POP  ES
     POP  DI                       ; restore DI
     POP  BP                       ; restore BP
     
     RET  2*4                      ; drop the 2 far parameter addresses

BINAND ENDP

; =================================================================

; SUBROUTINE NUMBIN ( INTEGER*2 N, CHARACTER*16 BUFFER )
;
; Microsoft Cobol 5.0
; Created by Martin Hepperle, 2024
;

NUMBIN_FRAME STRUC
               DW ?         ;  0  saved BP
               DW 2 DUP(?)  ;  2  RETURN address
   P_BUFFER    DW 2 DUP(?)  ;  6  BUFFER
   P_NUM       DW 2 DUP(?)  ;  A
NUMBIN_FRAME ENDS

PUBLIC NUMBIN

NUMBIN PROC FAR
     
     PUSH BP             ; save BP
     
     ; Stack frame is now:
     ; +A    OFF/SEG - BUFFER address
     ; +6    OFF/SEG - N address
     ; +2    OFF/SEG - return address
     ; SP -> BP - saved
     

     MOV  BP,SP          ; use BP for addressing of parameters
     
     PUSH  DI            ; save DI
     PUSH  ES            ; save ES

     ; get the number argument
     LOAD_ESDI P_NUM
     MOV  AX,WORD PTR ES:[DI]      ; 
     
     ; get the string buffer argument
     LOAD_ESDI P_BUFFER
     ADD  DI,16          ; behind last bit

     CALL BINIT

     POP  ES             ; restore ES
     POP  DI             ; restore DI
     POP  BP             ; restore BP
     
     RET  2*4            ; drop the 2 far parameter address

NUMBIN ENDP
; -----------------------------------------------------------------
BINIT PROC NEAR
     MOV  CX,16          ; bits
NEXTBIT:
     DEC  DI
     TEST AX,1
     JZ   ZERO
ONE:
     MOV  BYTE PTR ES:[DI],'1'
     JMP  CONTI
ZERO:
     MOV  BYTE PTR ES:[DI],'0'
CONTI:
     SHR  AX,1
     LOOP NEXTBIT
     RET  
BINIT ENDP

; =================================================================

; SUBROUTINE NUMHEX ( INTEGER*2 N, CHARACTER*4 BUFFER )
;
; Microsoft Cobol 5.0
; Created by Martin Hepperle, 2024
;

PUBLIC NUMHEX

NUMHEX PROC FAR
     
     PUSH BP             ; save BP
     
     ; Stack frame is now:
     ; +A    OFF/SEG - BUFFER address
     ; +6    OFF/SEG - N address
     ; +2    OFF/SEG - return address
     ; SP -> BP - saved
     

     MOV  BP,SP          ; use BP for addressing of parameters
     
     PUSH  DI            ; save DI
     PUSH  ES            ; save ES
          
     ; get the number argument
     LOAD_ESDI P_NUM
     MOV  AX,WORD PTR ES:[DI] 
     
     ; get the string buffer argument
     LOAD_ESDI P_BUFFER
     ADD  DI,4           ; behind last nibble

     CALL HEXIT

     POP  ES             ; restore ES
     POP  DI             ; restore DI
     POP  BP             ; restore BP
     
     RET  2*4            ; drop the 2 far parameter address

NUMHEX ENDP
; -----------------------------------------------------------------
HEXIT PROC NEAR
     MOV  CX,4           ; nibbles
NEXTNIB:
     DEC  DI
     MOV  BL,AL
     AND  BL,0FH         ; mask nibble
     CMP  BL,0AH
     JB   HEXDIG
     ADD  BL,'A'-'9'-1
HEXDIG:
     ADD  BL,'0'
     MOV  BYTE PTR ES:[DI],BL
     SHR  AX,1
     SHR  AX,1
     SHR  AX,1
     SHR  AX,1
     LOOP NEXTNIB
     RET  
HEXIT ENDP

; =================================================================

CODE ENDS

END
