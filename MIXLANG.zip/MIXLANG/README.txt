Mixed Language Programming with Microsoft Programming Languages
===============================================================
This Rosetta stone survival set serves as an example for using identical 
assembler routines in FUNC.ASM with various Microsoft programming languages
for MS-DOS:
- Microsoft Fortran 3.31
- Microsoft Pascal 3.31
- Microsoft Quick Basic 4.5
- Microsoft Quick C 2.5
[- Microsoft Cobol 5.0 (modifications to the assembler code were required)]

The main directory contains the tools MASM.EXE and LINK.EXE, as well as the 
assembler source code in FUNC.ASM which is used by all languages except Cobol.
A minimal set of compiler files and libraries for the individual languages are 
placed inside the directories FTN, PAS, BAS and C (in general, you should
install the complete development system for your language of choice).

Each of these directories contains a batch file GO.BAT which compiles,
assembles and links the example program ASM.EXE.
All these compiled programs should produce the same output.
If you want to use the full feature set of each compiler you should get the 
original distributions and install them on your system.
For Cobol only the source files and a batch file have been provided.


General Notes
=============
All integer parameters have been defined with a size of 32 bits (exception: Cobol). 
All pointers are defined as FAR pointers.
All subroutines are called via FAR calls.

Standard Calling Conventions
============================
"C" is the only language supporting subroutine calls with a variable number
of parameters by design. This implies that the caller is the only one who
knows how many parameters have been pushed to the stack.
Therefore, the CALLING routine has to clean up the stack AFTER EACH function call.
This adds flexibility but also increases the code size.

Pascal, Fortran and Basic expect that the stack is returned in a state with all parameters already removed.
Here, the CALLED routine cleans up the stack BEFORE RETURNING. This minimizes code size.
[This was one of the reasons why Microsoft Windows adopted the Pascal/Basic calling convention.
 Code size was especially important for early 16-bit Windows when memory was extremely scarce.]

Most compilers allow changing these standard calling conventions by compiler-specific keywords.

 
Assembler
=========
No language specific constructs have been used in the source code.
For historic consistency, MASM 3.0 is used; Borland's TASM also works fine for 
the examples.
All assembler routines are written to be called as FAR procedures resp. functions.
They expect all parameters as FAR pointers to the actual values (this is also 
called "call by reference").
String parameters are transferred as FAR pointers to the first 8-bit character 
of the string.
The assembler code should demonstrate the calling and return conventions - it
is not intended as an example of efficient programming style.


Fortran
=======
- Fortran always transfers its parameters as FAR pointers.
- All integers have to be INTEGER*4 (32 bit) integers.
- The string parameter is declared as an array of characters, one could also use
  a CHARACTER*80 variable instead.


Pascal
======
- The parameters have to be declared with the keyword Vars (not Var) to 
  transfer them as FAR pointers (the trailing 's' stands for segmented address).
- All integers have to be Integer4 (32 bit) integers.
- The string parameter is declared as a array of characters, which is identical 
  to a String(80) declaration.
  You cannot use the LString type because this has a length byte in its first 
  byte.


BASIC
=====
- Quick Basic 4.x offers the CALLS keyword, which performs a FAR call (the 
  trailing 'S' stands for Segmented address).
- All integers have to be LONG (32 bit) integers.
- Compared to other languages, Basic string parameters are addresses of string 
  descriptors, which are structures including the length and the address of the 
  actual string. These descriptors are used by complex memory handling functions
  which allocate, deallocate and move strings inside the string pool.
  In order to forward a FAR pointer to the actual characters of a string, 
  one has to 
  a) pre-allocate the string to the desired length, e.g. by assigning it a
     number of spaces, and,
  b) determine the segment and offset of the first character of the string
  before calling the assembler routine.
  Segment and offset have to be determined immediately before calling the
  assembler routine, because any string manipulation in BASIC may move the
  string around in string space.
  This is accomplished by the SADD() function for the offset while VARSEG()
  returns the segment.
  The actual function call uses two 16-bit integer parameters to push the
  segment and offset to the stack in the proper order.
  The result is the same as pushing a FAR pointer like in Pascal or Fortran.

  
"C"
===
- I have used the command line compiler from the Quick C package as well as 
  MASM and LINK. 
  You could also use the full "Quick C with Assembler" package or the Microsoft 
  "C" compiler 4.0 by replacing QCL by CL and QLINK by LINK. 
- The names of external routines have to be decorated with _fortran to avoid the 
  compiler prepending a leading underscore to the name and to tell it that 
  parameter cleanup is performed inside each subroutine or function (contrary to
  standard "C" calling conventions).
- The parameters have to be transferred as _far pointers.
- All integers have to be declared as long (32 bit) integers.
- The string parameter is declared as a array of characters and a '\0' character 
  is required to terminate the output for usage with printf().


MS-Cobol 5.0
============
- The Cobol system is very robust when it calls external routines. 
  For example is saves and restores the stack pointer so that many stack 
  handling errors inside assembler routines would have no effect, as long 
  as the return address is not destroyed. Also, DS and ES are restored.
- The number of parameters is passed in register CX.
- The calling conventions in MS-Cobol can be adjusted to match all other
  Microsoft languages (far pointers, left to right parameter sequence).
- However, Cobol seems to have no support for native 32-bit integers.
  Therefore, the assembler code has been adapted to 16-bit integer parameters
  and return values. The file CBLFUNC.ASM contains this modified code.
- Finally, the Cobol code should be linked statically to the *.OBJ module.
  This allows having multiple subroutines in a single *.OBJ file (by default,
  Cobol loads external subroutines from individual *.EXE modules at run time).
  The static linking option may not exist in previous versions of MS-Cobol,
  like Cobol 3.0.


Martin Hepperle, 2024
